1. Add session keeper - https://www.bookrailticket.com/how-prevent-session-expired-irctc-login-keep-working-longer-duration
2. Allow multiple logins using incognito tabs
3. Handle IRCTC - error
4. Handle script failure
5. Train details - input
6. Add script status indicator on screen
